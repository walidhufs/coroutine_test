package com.example.coroutinetest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings.Global
import android.util.Log
import android.util.TimeUtils
import android.widget.TextView
import kotlinx.coroutines.*

val TAG = "Coroutine"
var count:Int = 0
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val uiScope = CoroutineScope(Dispatchers.Main)
        uiScope.launch{
            main()
        }

    }
    suspend fun main(){
        Log.v(TAG, "main:0")
        val var1 = one()
        val var2 = two()

        // this should be run continously
        val txt = findViewById<TextView>(R.id.txt)
        for (i in 1..10){
            txt.setText(i.toString())
            Log.v(TAG, "main:"+i.toString())
            delay(100)
        }

        //this should only run when the result is computed
        val result = var1 + var2
        Log.v(TAG, result.toString())
        txt.setText("result="+result.toString())
    }
    suspend fun one():Int{
        for (i in 1..10) {
            Log.v(TAG, "one:"+i.toString())
            delay(1000)
        }
        return 100
    }
    suspend fun two():Int{
        for (i in 1..10) {
            Log.v(TAG, "two:"+i.toString())
            delay(1000)
        }
        return 200
    }

}